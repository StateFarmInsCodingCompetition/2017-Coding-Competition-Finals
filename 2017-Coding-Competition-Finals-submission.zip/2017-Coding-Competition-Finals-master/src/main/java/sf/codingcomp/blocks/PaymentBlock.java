package sf.codingcomp.blocks;

public class PaymentBlock extends Block<Payment> {

    public PaymentBlock(Payment data) {
        super(data);
    }

}
