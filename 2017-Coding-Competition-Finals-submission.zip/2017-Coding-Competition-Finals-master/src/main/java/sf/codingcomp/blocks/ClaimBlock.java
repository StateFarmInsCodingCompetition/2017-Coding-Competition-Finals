package sf.codingcomp.blocks;

public class ClaimBlock extends Block<Claim> {

    public ClaimBlock(Claim data) {
        super(data);
    }

}
