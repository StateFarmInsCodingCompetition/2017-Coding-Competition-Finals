package sf.codingcomp.blocks;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class Blockchain implements Serializable{

    private List<Block<?>> chain;

    public Blockchain() {
        super();
        
        Block<?> genesisBlock = new Block<>(null);
        genesisBlock.setHash(VerificationHashFactory.buildVerificationHash(genesisBlock));
        
        chain = new LinkedList<Block<?>>();
        chain.add(genesisBlock);
        
    }

    public void addBlock(Block<?> block) {

    	block.setPreviousHash(chain.get(chain.size()-1).getHash());
    	block.setHash(VerificationHashFactory.buildVerificationHash(block));
    	chain.add(block);
    	
    }

    public boolean verify(){
    	if(chain.size()<1) return false;
    	if(chain.size()==1) return true;

    	System.out.println();
    	for(int i=1; i<chain.size(); i++){
    		if(!validate(chain.get(i), chain.get(i-1))) return false;
    	}
    	return true;
    	
    }
    
    public int size(){
    	return chain.size();
    }
    
    private boolean validate(Block<?> b, Block<?> prev){
    	return b.validate() && prev.getHash()!=null && prev.getHash().equals(b.getPreviousHash());
    }

}
