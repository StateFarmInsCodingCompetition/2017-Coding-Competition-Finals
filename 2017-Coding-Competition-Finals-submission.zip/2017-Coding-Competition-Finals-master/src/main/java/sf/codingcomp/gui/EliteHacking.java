package sf.codingcomp.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.springframework.test.util.ReflectionTestUtils;

import sf.codingcomp.blocks.Block;
import sf.codingcomp.blocks.Blockchain;
import sf.codingcomp.blocks.Payment;
import sf.codingcomp.blocks.PaymentBlock;

import javax.swing.JTextPane;
import javax.swing.SpringLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class EliteHacking extends JFrame {

	private JPanel contentPane;
	private JTextField txtAmount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args){
		EventQueue.invokeLater(new Runnable() {
			public void run(){
				try{
					EliteHacking frame = new EliteHacking();
					frame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EliteHacking(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JTextPane txtpnHackMoneyInto = new JTextPane();
		txtpnHackMoneyInto.setText("Hack money into your account!!!!");
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtpnHackMoneyInto, 10, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtpnHackMoneyInto, -207, SpringLayout.EAST, contentPane);
		contentPane.add(txtpnHackMoneyInto);
		
		txtAmount = new JTextField();
		txtAmount.setText("Amount");
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtAmount, 6, SpringLayout.SOUTH, txtpnHackMoneyInto);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtAmount, 54, SpringLayout.WEST, contentPane);
		contentPane.add(txtAmount);
		txtAmount.setColumns(10);
		
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PaymentBlock block = new PaymentBlock(new Payment(0, 10, Double.valueOf(txtAmount.getText())));

		        LinkedList<Block<?>> badChain = (LinkedList<Block<?>>) ReflectionTestUtils.getField(bc, "chain");
		        badChain.add(block);
				saveBC();
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnConfirm, 6, SpringLayout.SOUTH, txtAmount);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnConfirm, 10, SpringLayout.WEST, txtAmount);
		contentPane.add(btnConfirm);
		
		init();
	}


	private Blockchain bc;
	private File bcFile;
	
	private void init(){
		//if there's a valid blockchain, use that
		File bcFolder = new File("chains/");
		
		if(!bcFolder.exists()) bcFolder.mkdir();
		
		File[] chains = bcFolder.listFiles();
		if(chains!=null) for(File f : chains){
			ObjectInputStream is;
			Blockchain b = null;
			try{
				is = new ObjectInputStream(new FileInputStream(f));
				b = (Blockchain) is.readObject();
				is.close();
			}catch(IOException | ClassNotFoundException e){
				e.printStackTrace();
				b = null;
			}
			
			if(b!=null){
				if(b.verify()){
					if(bc==null || bc.size()<b.size()){
						bc = b;
						bcFile = f;
					}
				}else{
					JOptionPane.showMessageDialog(null, "Someone appears to have illicitly modified the blockchain: "+f.getName(), "Invalid Blockchain", JOptionPane.WARNING_MESSAGE);
				}
			}
		}
		
		//if there isn't already a chain, make one
		if(bc==null){
			bc = new Blockchain();
			bcFile = new File("chains/chain_0.chain");			
			
		}
		
		
		
	}
	
	private final void saveBC(){		
		try{
			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(bcFile));
			os.writeObject(bc);
			os.close();
		}catch(IOException e){
//			JOptionPane.showMessageDialog(null, "Error Saving Block Chain", "Invalid Payment", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
			System.exit(1);
		}		
	}
	
}
