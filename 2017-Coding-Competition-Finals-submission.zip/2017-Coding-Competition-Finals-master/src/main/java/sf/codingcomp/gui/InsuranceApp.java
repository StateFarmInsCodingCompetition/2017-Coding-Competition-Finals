package sf.codingcomp.gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SpringLayout;
import javax.swing.border.EmptyBorder;

import sf.codingcomp.blocks.Blockchain;
import sf.codingcomp.blocks.Claim;
import sf.codingcomp.blocks.ClaimBlock;
import sf.codingcomp.blocks.Payment;
import sf.codingcomp.blocks.PaymentBlock;

public class InsuranceApp extends JFrame {

	private JPanel contentPane;
	private JTextField userIDField;
	private JTextPane textPane;
	private JTextPane txtpnPassword;
	private JTextField passwordField;
	private JTextField paymentField;
	private JTextPane txtpnMakeClaim;
	private JTextField faultField;
	private JTextField damageField;
	private JButton btnClaimConfirm;

	private User currentUser;
	private Blockchain bc;
	private File bcFile;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args){
		EventQueue.invokeLater(new Runnable() {
			public void run(){
				try{
					InsuranceApp frame = new InsuranceApp();
					frame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InsuranceApp(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JTextPane txtpnUserId = new JTextPane();
		txtpnUserId.setText("User id");
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtpnUserId, 10, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtpnUserId, 10, SpringLayout.WEST, contentPane);
		contentPane.add(txtpnUserId);
		
		userIDField = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, userIDField, 6, SpringLayout.SOUTH, txtpnUserId);
		sl_contentPane.putConstraint(SpringLayout.WEST, userIDField, 10, SpringLayout.WEST, txtpnUserId);
		contentPane.add(userIDField);
		userIDField.setColumns(10);
		
		txtpnPassword = new JTextPane();
		txtpnPassword.setText("Password");
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtpnPassword, 6, SpringLayout.SOUTH, userIDField);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtpnPassword, 0, SpringLayout.WEST, txtpnUserId);
		contentPane.add(txtpnPassword);
		
		passwordField = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, passwordField, 6, SpringLayout.SOUTH, txtpnPassword);
		sl_contentPane.putConstraint(SpringLayout.EAST, passwordField, 0, SpringLayout.EAST, userIDField);
		contentPane.add(passwordField);
		passwordField.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int id = 0;
				try{
					id = Integer.valueOf(userIDField.getText());
					
					currentUser = new User(id);
					
					paymentField.setEditable(true);
					damageField.setEditable(true);
					faultField.setEditable(true);
				}catch(Exception asdf){
					JOptionPane.showMessageDialog(null, "Please enter a valid numerical user id", "Invalid UserID", JOptionPane.ERROR_MESSAGE);
				}			
				
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnLogin, 6, SpringLayout.SOUTH, passwordField);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnLogin, 0, SpringLayout.EAST, userIDField);
		contentPane.add(btnLogin);
		
		JTextPane txtpnMakePayment = new JTextPane();
		txtpnMakePayment.setText("Make Payment");
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtpnMakePayment, 0, SpringLayout.NORTH, txtpnUserId);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtpnMakePayment, -10, SpringLayout.EAST, contentPane);
		contentPane.add(txtpnMakePayment);
		
		paymentField = new JTextField();
		paymentField.setEditable(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, paymentField, 0, SpringLayout.NORTH, userIDField);
		sl_contentPane.putConstraint(SpringLayout.EAST, paymentField, -10, SpringLayout.EAST, contentPane);
		contentPane.add(paymentField);
		paymentField.setColumns(10);
		
		JButton btnPaymentConfirm = new JButton("Confirm");
		btnPaymentConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pay = 0;
				try{
					pay = Double.valueOf(paymentField.getText());
					if(pay<0) throw new RuntimeException();
					
					bc.addBlock(new PaymentBlock(new Payment(currentUser.id, 0, pay)));
					
					saveBC();
					
				}catch(Exception asdf){
					JOptionPane.showMessageDialog(null, "Please enter a valid payment", "Invalid Payment", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnPaymentConfirm, 0, SpringLayout.NORTH, txtpnPassword);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnPaymentConfirm, 0, SpringLayout.EAST, txtpnMakePayment);
		contentPane.add(btnPaymentConfirm);
		
		txtpnMakeClaim = new JTextPane();
		txtpnMakeClaim.setText("Make Claim");
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtpnMakeClaim, 0, SpringLayout.NORTH, btnLogin);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtpnMakeClaim, 0, SpringLayout.EAST, txtpnMakePayment);
		contentPane.add(txtpnMakeClaim);
		
		faultField = new JTextField();
		faultField.setEditable(false);
		faultField.setText("User at fault");
		sl_contentPane.putConstraint(SpringLayout.NORTH, faultField, 6, SpringLayout.SOUTH, txtpnMakeClaim);
		sl_contentPane.putConstraint(SpringLayout.WEST, faultField, 0, SpringLayout.WEST, paymentField);
		contentPane.add(faultField);
		faultField.setColumns(10);
		
		damageField = new JTextField();
		damageField.setEditable(false);
		damageField.setText("Damage amount");
		sl_contentPane.putConstraint(SpringLayout.NORTH, damageField, 6, SpringLayout.SOUTH, faultField);
		sl_contentPane.putConstraint(SpringLayout.WEST, damageField, 0, SpringLayout.WEST, paymentField);
		contentPane.add(damageField);
		damageField.setColumns(10);
		
		btnClaimConfirm = new JButton("Confirm");
		btnClaimConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double dmg = 0;
				int fault = 0;
				try{
					dmg = Double.valueOf(damageField.getText());
					fault = Integer.valueOf(userIDField.getText());
					if(dmg<0) throw new RuntimeException();
					
					bc.addBlock(new ClaimBlock(new Claim(fault, currentUser.id, dmg)));
					
					saveBC();
					
				}catch(Exception asdf){
					JOptionPane.showMessageDialog(null, "Please enter a valid amount of Damages and user id", "Invalid Claim", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnClaimConfirm, 6, SpringLayout.SOUTH, damageField);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnClaimConfirm, 0, SpringLayout.EAST, txtpnMakePayment);
		contentPane.add(btnClaimConfirm);
		
		init();
		
		
	}
	
	
	private void init(){
		//if there's a valid blockchain, use that
		File bcFolder = new File("chains/");
		
		if(!bcFolder.exists()) bcFolder.mkdir();
		
		File[] chains = bcFolder.listFiles();
		if(chains!=null) for(File f : chains){
			ObjectInputStream is;
			Blockchain b = null;
			try{
				is = new ObjectInputStream(new FileInputStream(f));
				b = (Blockchain) is.readObject();
				is.close();
			}catch(IOException | ClassNotFoundException e){
				e.printStackTrace();
				b = null;
			}
			
			if(b!=null){
				if(b.verify()){
					if(bc==null || bc.size()<b.size()){
						bc = b;
						bcFile = f;
					}
				}else{
					JOptionPane.showMessageDialog(null, "Someone appears to have illicitly modified the blockchain: "+f.getName(), "Invalid Blockchain", JOptionPane.WARNING_MESSAGE);
				}
			}
		}
		
		//if there isn't already a chain, make one
		if(bc==null){
			bc = new Blockchain();
			bcFile = new File("chains/chain_0.chain");
			
			
			
			
		}
		
	}
	
	
	
	private final void saveBC(){		
		try{
			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(bcFile));
			os.writeObject(bc);
			os.close();
		}catch(IOException e){
//			JOptionPane.showMessageDialog(null, "Error Saving Block Chain", "Invalid Payment", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
			System.exit(1);
		}		
	}
	
	
}
