package sf.codingcomp.gui;

public class User {

	public final int id;

	public User(int id){
		super();
		this.id = id;
	}
	
	public final boolean verifyPassword(){
		//TODO fill in later
		return true;
	}
	
}
